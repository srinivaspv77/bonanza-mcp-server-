
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.auth import ApiKeyMiddleware
from app.routes_core import router as core_router
from app.routes_discovery import router as discovery_router
from app.routes_options import router as options_router
from app.config import ALLOWED_ORIGINS

app = FastAPI(title="Bonanza MCP Server - Deribit Gateway", version="1.0.0")
app.add_middleware(ApiKeyMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(core_router)
app.include_router(discovery_router)
app.include_router(options_router)
