
import os

DERIBIT_BASE = os.getenv("DERIBIT_BASE", "https://www.deribit.com")
HTTP_TIMEOUT = float(os.getenv("HTTP_TIMEOUT", "20"))
MAX_POINTS = int(os.getenv("MAX_POINTS", "5000"))
API_KEY = os.getenv("API_KEY")  # required in prod
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
DATABASE_URL = os.getenv("DATABASE_URL")  # optional, for skew
