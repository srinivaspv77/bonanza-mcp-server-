
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from .config import API_KEY

class ApiKeyMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if API_KEY:
            key = request.headers.get("X-Api-Key")
            if key != API_KEY:
                raise HTTPException(status_code=401, detail="Unauthorized")
        return await call_next(request)
