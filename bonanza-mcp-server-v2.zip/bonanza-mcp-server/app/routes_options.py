
from fastapi import APIRouter, Query
from .config import DERIBIT_BASE
from .http import get_json
from .schemas import ok
import time

router = APIRouter(prefix="/options", tags=["options"])

@router.get("/instruments")
async def options_instruments(
    asset: str = Query(..., pattern="^(BTC|ETH)$"),
    expired: bool = False
):
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_instruments", {
        "currency": asset, "kind": "option", "expired": str(expired).lower()
    })
    return ok({"rows": j.get("result", [])})

@router.get("/chain")
async def options_chain(
    asset: str = Query(..., pattern="^(BTC|ETH)$"),
    date: str | None = None
):
    # filter by expiry date YYYY-MM-DD if provided
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_instruments", {
        "currency": asset, "kind": "option", "expired": "false"
    })
    rows = j.get("result", [])
    if date:
        # Deribit returns expiration_timestamp in ms; rough match by prefix if you roll your own map
        # For simplicity, we pass all rows — client can filter as needed.
        pass
    return ok({"rows": rows})

@router.get("/iv_surface")
async def iv_surface(asset: str = Query(..., pattern="^(BTC|ETH)$"), date: str | None = None):
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_instruments", {
        "currency": asset, "kind": "option", "expired": "false"
    })
    rows = j.get("result", [])
    pts = []
    now = int(time.time()*1000)
    for r in rows:
        if date:
            # optional: filter by date
            pass
        iv = r.get("mark_iv") or r.get("implied_volatility") or r.get("estimated_delivery_price")
        if iv is None:
            continue
        ttm_days = max(1.0, (r["expiration_timestamp"] - now)/86400000)
        if r.get("strike") is None:
            continue
        pts.append({"ttm_days": round(ttm_days, 2), "strike": float(r["strike"]), "iv": float(iv) * 100.0})
    return ok({"points": pts, "meta":{"asset": asset, "note":"Derived from option instruments"}})

@router.get("/term_structure")
async def term_structure(asset: str = Query(..., pattern="^(BTC|ETH)$")):
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_instruments", {
        "currency": asset, "kind": "option", "expired": "false"
    })
    rows = j.get("result", [])
    by_exp = {}
    now = int(time.time()*1000)
    for r in rows:
        k = r.get("expiration_timestamp")
        if not k: 
            continue
        by_exp.setdefault(k, []).append(r)
    points = []
    for k, bucket in by_exp.items():
        ivs = [x.get("mark_iv") or x.get("implied_volatility") for x in bucket if (x.get("mark_iv") or x.get("implied_volatility"))]
        if not ivs: 
            continue
        iv = sum(ivs)/len(ivs)*100.0
        days = (k - now)/86400000
        points.append({"expiry": k, "days": round(days,2), "iv": iv})
    points.sort(key=lambda x: x["days"])
    return ok({"points": points, "meta":{"asset": asset}})

@router.get("/skew_25d")
async def skew_25d(asset: str = Query(..., pattern="^(BTC|ETH)$")):
    # Placeholder: wire to your DB if you run the ingestor
    return ok({"points": [], "meta": {"asset": asset, "note":"fill via ingest_skew.py and DB"}})
