
import httpx
from .config import HTTP_TIMEOUT

async def get_json(url: str, params: dict | None = None):
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
        r = await client.get(url, params=params or {})
        r.raise_for_status()
        j = r.json()
        return j
