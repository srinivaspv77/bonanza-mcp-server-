
from fastapi import APIRouter, Query
from .config import DERIBIT_BASE, MAX_POINTS
from .http import get_json
from .schemas import ok, clamp
import time, math

router = APIRouter(prefix="", tags=["core"])

@router.get("/health")
async def health():
    return ok(True)

@router.get("/assets")
async def assets():
    return ok(["BTC","ETH"])

@router.get("/prices/index")
async def index_price(
    asset: str = Query(..., pattern="^(BTC|ETH)$"),
    start: int | None = None,
    end: int | None = None,
    interval: str = "1h",
    max_points: int = MAX_POINTS
):
    # Use tradingview data for price history
    params = {
        "instrument_name": f"{asset}-PERPETUAL",
        "start_timestamp": start, 
        "end_timestamp": end,
        "resolution": interval
    }
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_tradingview_chart_data", params)
    data = j.get("result", {}).get("data", [])
    series = [{"t": x["ticks"], "v": x["close"], "unit":"USD"} for x in data]
    return ok(clamp(series, max_points))

@router.get("/indices/fixing")
async def fixing_indices(asset: str = Query(..., pattern="^(BTC|ETH)$")):
    # Deribit exposes index price; treat as fixing-like reference for simplicity
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_index_price", {"index_name": asset})
    res = j.get("result", {})
    table = [{
        "symbol": f"{asset}-USD", 
        "value": res.get("index_price"), 
        "unit":"USD", 
        "ts": res.get("timestamp")
    }]
    return ok({"rows": table, "meta":{"asset": asset}})

@router.get("/vol/dvol")
async def dvol(
    asset: str = Query(..., pattern="^(BTC|ETH)$"),
    start: int | None = None,
    end: int | None = None,
    interval: str = "1d",
    max_points: int = MAX_POINTS
):
    # If available use Deribit DVOL series; otherwise empty.
    try:
        j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_volatility_index_data",
                           {"currency": asset, "start_timestamp": start, "end_timestamp": end, "resolution": interval})
        series = [{"t": r["timestamp"], "v": r["dvol"], "unit":"%"} for r in j.get("result",[])]
        return ok(clamp(series, max_points))
    except Exception:
        return ok([])

@router.get("/vol/hv")
async def historical_vol(
    asset: str = Query(..., pattern="^(BTC|ETH)$"),
    window: int = 30,
    start: int | None = None,
    end: int | None = None
):
    # Compute close-to-close realized vol from daily closes
    params = {
        "instrument_name": f"{asset}-PERPETUAL",
        "start_timestamp": start, 
        "end_timestamp": end,
        "resolution": "1d"
    }
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_tradingview_chart_data", params)
    data = j.get("result", {}).get("data", [])
    closes = [x["close"] for x in data]
    ts = [x["ticks"] for x in data]
    if len(closes) < window + 2:
        return ok([])
    import math, statistics
    rets = [math.log(closes[i]/closes[i-1]) for i in range(1,len(closes))]
    series = []
    for i in range(window, len(rets)+1):
        vol = statistics.pstdev(rets[i-window:i]) * (365**0.5) * 100.0
        series.append({"t": ts[i], "v": vol, "unit":"%"})
    return ok(series)

@router.get("/futures/funding")
async def funding(
    asset: str = Query(..., pattern="^(BTC|ETH)$"),
    start: int | None = None,
    end: int | None = None,
    max_points: int = MAX_POINTS
):
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_funding_rate_history", {
        "instrument_name": f"{asset}-PERPETUAL",
        "start_timestamp": start, "end_timestamp": end
    })
    series = [{"t": r["timestamp"], "v": r["funding_rate"]*100.0, "unit":"%/8h"} for r in j.get("result",[])]
    return ok(clamp(series, max_points))

@router.get("/system/insurance")
async def insurance(asset: str = Query(..., pattern="^(BTC|ETH)$")):
    j = await get_json(f"{DERIBIT_BASE}/api/v2/public/get_insurance", {"currency": asset})
    rows = [{
        "asset": asset, 
        "balance": j.get("result",{}).get("balance"), 
        "unit": asset, 
        "ts": j.get("result",{}).get("timestamp")
    }]
    return ok({"rows": rows})

@router.get("/system/proof_of_reserves")
async def proof_of_reserves():
    # Placeholder. Populate with Deribit PoR artifacts when available.
    return ok({"rows":[{"type":"merkle_root","value":"<hash>", "ts": int(time.time()*1000)}]})

@router.get("/metric")
async def metric(metric: str, asset: str | None = None, interval: str = "1d",
                 start: int | None = None, end: int | None = None, max_points: int = MAX_POINTS):
    MAP = {
        "index_price": ("/prices/index", {"asset": asset, "interval": interval, "start": start, "end": end, "max_points": max_points}),
        "dvol": ("/vol/dvol", {"asset": asset, "interval": interval, "start": start, "end": end, "max_points": max_points}),
        "funding_rate": ("/futures/funding", {"asset": asset, "start": start, "end": end, "max_points": max_points}),
        "hv_30d": ("/vol/hv", {"asset": asset, "window": 30, "start": start, "end": end}),
    }
    if metric not in MAP:
        from fastapi import HTTPException
        raise HTTPException(404, f"Unknown metric: {metric}")
    path, params = MAP[metric]
    # Call our own gateway endpoints
    from fastapi import Request
    # Construct absolute call path via local import to avoid circular request; simpler:
    # For now just proxy by recomputing here:
    if metric == "index_price":
        return await index_price(**params)
    if metric == "dvol":
        return await dvol(**params)
    if metric == "funding_rate":
        return await funding(**params)
    if metric == "hv_30d":
        return await historical_vol(**params)
