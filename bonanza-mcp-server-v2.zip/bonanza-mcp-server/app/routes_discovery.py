
from fastapi import APIRouter
from .schemas import ok

router = APIRouter(prefix="", tags=["discovery"])

@router.get("/indices")
async def indices_catalog():
    return ok([
        {"key": "index_price", "desc": "Spot index price (perpetual index)"},
        {"key": "mark_price", "desc": "Mark price (add if you wire it)"},
        {"key": "fair_price", "desc": "Fair price (add if you wire it)"},
        {"key": "dvol", "desc": "Deribit Volatility Index (if available)"},
        {"key": "fixing_indices", "desc": "Reference fixing indices (USD pairs)"},
    ])

@router.get("/options/metrics")
async def options_metrics_catalog():
    return ok([
        {"key":"iv_surface","desc":"Implied vol surface (strike×expiry grid)"},
        {"key":"term_structure","desc":"Average IV across expiries"},
        {"key":"skew_25d","desc":"25-delta put/call skew (requires ingest)"},
        {"key":"rr_25d","desc":"25-delta risk reversal (extend if needed)"},
        {"key":"oi_notional","desc":"Open interest notional by expiry/strike (extend)"},
        {"key":"volume","desc":"Options volume by day (extend)"},
        {"key":"greeks","desc":"Aggregate greeks (delta, gamma, vega, theta) (extend)"},
    ])

@router.get("/futures/metrics")
async def futures_metrics_catalog():
    return ok([
        {"key":"funding_rate","desc":"Perpetual funding (series)"},
        {"key":"basis","desc":"Annualized basis vs index (extend)"},
        {"key":"term_structure","desc":"Futures curve / forward vs expiry (extend)"},
        {"key":"oi_volume","desc":"Futures open interest & volume (extend)"},
    ])
