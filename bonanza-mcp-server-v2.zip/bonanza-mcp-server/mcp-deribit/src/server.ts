
import { Server, Tool } from "@modelcontextprotocol/sdk/server";
import fetch from "node-fetch";

const GATEWAY = process.env.GATEWAY_BASE || "http://localhost:8082";

async function j(path: string, params: Record<string, any> = {}) {
  const url = new URL(path, GATEWAY);
  Object.entries(params).forEach(([k, v]) => v !== undefined && url.searchParams.set(k, String(v)));
  const r = await fetch(url.toString());
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  const body = await r.json();
  if (!body.ok) throw new Error("Gateway error");
  return body.data;
}

const tools: Tool[] = [
  { name: "list_assets", description: "BTC/ETH assets.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, handler: async () => await j("/assets") },
  { name: "get_index_price", description: "Index price series.", inputSchema: { type: "object", properties: { asset: { enum: ["BTC","ETH"] }, start: { type: "number" }, end:{ type: "number" }, interval:{ type: "string", default: "1h" }, max_points:{ type: "number", default: 2000 } }, required:["asset"], additionalProperties: false }, handler: async (i:any)=> await j("/prices/index", i) },
  { name: "get_dvol", description: "DVOL time series.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] }, start:{ type:"number" }, end:{ type:"number" }, interval:{ type:"string", default:"1d" } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/vol/dvol", i) },
  { name: "get_hv", description: "Historical realized vol.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] }, window:{ type:"number", default:30 }, start:{ type:"number" }, end:{ type:"number" } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/vol/hv", i) },
  { name: "get_funding", description: "Perp funding history.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] }, start:{ type:"number" }, end:{ type:"number" } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/futures/funding", i) },
  { name: "get_insurance", description: "Insurance fund balance.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/system/insurance", i) },
  { name: "get_fixings", description: "Fixing indices table.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/indices/fixing", i) },
  { name: "get_term_structure", description: "Options term structure.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/options/term_structure", i) },
  { name: "get_iv_surface", description: "Options IV surface points.", inputSchema: { type: "object", properties: { asset:{ enum:["BTC","ETH"] }, date:{ type:"string" } }, required:["asset"], additionalProperties:false }, handler: async (i:any)=> await j("/options/iv_surface", i) },
  { name: "fetch_metric", description: "Generic metric fetch by slug.", inputSchema: { type: "object", properties: { metric:{ type:"string" }, asset:{ enum:["BTC","ETH"], nullable:true }, start:{ type:"number", nullable:true }, end:{ type:"number", nullable:true }, interval:{ type:"string", default:"1d" }, max_points:{ type:"number", default:2000 } }, required:["metric"], additionalProperties:false }, handler: async (i:any)=> await j("/metric", i) },
];

async function main(){
  const server = new Server({ name: "bonanza-mcp-server", version: "1.0.0" });
  tools.forEach(t => server.tool(t));
  const transport = await server.createStdioServer();
  await transport.start();
}

main().catch(e => { console.error(e); process.exit(1); });
